package entity;

public class Clothing extends Product{
	 
		public Clothing(int productId, String productName, String description, double price, int quantityInStock,
			String type, String size2, String color2) {
		// TODO Auto-generated constructor stub
	}
		String size;
		String color;
		
		}
		

