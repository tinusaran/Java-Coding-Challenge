package entity;

public class Electronics extends Product {

		public Electronics(int productId, String productName, String description, double price, int quantityInStock,
			String type, String brand2, int warrantyPeriod2) {
		// TODO Auto-generated constructor stub
	}
		String brand;
		int warrantyPeriod;
		
	
		}

